<%@ include file="../includes/sidebar_admin.jsp" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Blogs</title>
    <link rel="stylesheet" type="text/css" href="<%= request.getContextPath() %>/css/manage_blogs.css">
</head>
<body>
    <div class="container">
        <h2 class="page-title">Manage Blogs</h2>

        <c:if test="${not empty error}">
            <div class="alert-message error">${error}</div>
        </c:if>

        <!-- Blog Table -->
        <table class="data-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Likes</th>
                    <th>Comments</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="blog" items="${blogs}">
                    <tr>
                        <td>
                            <img src="${pageContext.request.contextPath}/${blog.imageUrl}" class="blog-thumbnail" alt="Blog Image">
                        </td>
                        <td><c:out value="${blog.title}"/></td>
                        <td><c:out value="${blog.content}"/></td>
                        <td><c:out value="${blog.totalLikes}"/></td>
                        <td><c:out value="${blog.totalComments}"/></td>
                        <td class="action-buttons">
                            <a href="viewBlogDetails?post_id=${blog.postId}" class="btn btn-view">View</a>
                            <a href="deleteBlog?post_id=${blog.postId}" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this blog?')">Delete</a>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </div>
</body>
</html>